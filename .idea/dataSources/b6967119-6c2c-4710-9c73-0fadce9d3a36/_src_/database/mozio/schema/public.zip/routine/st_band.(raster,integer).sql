create function st_band(rast raster, nband integer) returns raster
LANGUAGE SQL
AS $$
SELECT  public.ST_band($1, ARRAY[$2])
$$;
