create function st_approxcount(rastertable text, rastercolumn text, nband integer, sample_percent double precision) returns bigint
LANGUAGE SQL
AS $$
SELECT public._ST_count($1, $2, $3, TRUE, $4)
$$;
