create function st_tri(rast raster, nband integer DEFAULT 1, pixeltype text DEFAULT '32BF'::text, interpolate_nodata boolean DEFAULT false) returns raster
LANGUAGE SQL
AS $$
SELECT public.ST_tri($1, $2, NULL::raster, $3, $4)
$$;
