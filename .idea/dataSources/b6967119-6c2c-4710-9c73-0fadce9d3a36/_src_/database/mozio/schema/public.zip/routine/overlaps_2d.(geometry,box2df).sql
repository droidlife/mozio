create function overlaps_2d(geometry, box2df) returns boolean
LANGUAGE SQL
AS $$
SELECT $2 OPERATOR(public.&&) $1;
$$;
