create function postgis_scripts_build_date() returns text
LANGUAGE SQL
AS $$
SELECT '2017-02-03 23:53:16'::text AS version
$$;
