create function st_summarystats(rast raster, exclude_nodata_value boolean) returns summarystats
LANGUAGE SQL
AS $$
SELECT public._ST_summarystats($1, 1, $2, 1)
$$;
