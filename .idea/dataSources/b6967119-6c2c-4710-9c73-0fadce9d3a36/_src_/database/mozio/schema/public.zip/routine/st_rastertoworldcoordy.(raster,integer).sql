create function st_rastertoworldcoordy(rast raster, yr integer) returns double precision
LANGUAGE SQL
AS $$
SELECT latitude FROM public._ST_rastertoworldcoord($1, NULL, $2)
$$;
