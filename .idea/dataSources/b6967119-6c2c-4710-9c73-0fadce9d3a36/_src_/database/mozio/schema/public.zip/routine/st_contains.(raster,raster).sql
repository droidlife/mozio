create function st_contains(rast1 raster, rast2 raster) returns boolean
LANGUAGE SQL
AS $$
SELECT public.st_contains($1, NULL::integer, $2, NULL::integer)
$$;
