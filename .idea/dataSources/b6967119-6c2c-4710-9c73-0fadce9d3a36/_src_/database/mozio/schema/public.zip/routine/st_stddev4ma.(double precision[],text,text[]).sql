create function st_stddev4ma(matrix double precision[], nodatamode text, VARIADIC args text[]) returns double precision
LANGUAGE SQL
AS $$
SELECT stddev(unnest) FROM unnest($1)
$$;
