create function st_numpatches(geometry) returns integer
LANGUAGE SQL
AS $$
SELECT CASE WHEN public.ST_GeometryType($1) = 'ST_PolyhedralSurface'
	THEN public.ST_NumGeometries($1)
	ELSE NULL END

$$;
