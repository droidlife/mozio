create function st_transform(geom geometry, to_proj text) returns geometry
LANGUAGE SQL
AS $$
SELECT postgis_transform_geometry($1, proj4text, $2, 0)
FROM spatial_ref_sys WHERE srid=public.ST_SRID($1);
$$;
