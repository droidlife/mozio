create function st_voronoipolygons(g1 geometry, tolerance double precision DEFAULT 0.0, extend_to geometry DEFAULT NULL::geometry) returns geometry
LANGUAGE SQL
AS $$
SELECT public._ST_Voronoi(g1, extend_to, tolerance, true)
$$;
