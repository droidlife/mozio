create function st_approxquantile(rastertable text, rastercolumn text, sample_percent double precision, quantile double precision) returns double precision
LANGUAGE SQL
AS $$
SELECT ( public._ST_quantile($1, $2, 1, TRUE, $3, ARRAY[$4]::double precision[])).value
$$;
