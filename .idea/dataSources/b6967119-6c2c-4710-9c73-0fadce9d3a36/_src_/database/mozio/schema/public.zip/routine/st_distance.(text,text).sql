create function st_distance(text, text) returns double precision
LANGUAGE SQL
AS $$
SELECT ST_Distance($1::public.geometry, $2::public.geometry);
$$;
