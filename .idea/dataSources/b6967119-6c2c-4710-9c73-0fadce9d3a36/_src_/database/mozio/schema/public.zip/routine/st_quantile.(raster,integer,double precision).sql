create function st_quantile(rast raster, nband integer, quantile double precision) returns double precision
LANGUAGE SQL
AS $$
SELECT ( public._ST_quantile($1, $2, TRUE, 1, ARRAY[$3]::double precision[])).value
$$;
