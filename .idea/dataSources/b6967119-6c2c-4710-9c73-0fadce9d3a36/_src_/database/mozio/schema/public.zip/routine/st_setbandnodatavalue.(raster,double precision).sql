create function st_setbandnodatavalue(rast raster, nodatavalue double precision) returns raster
LANGUAGE SQL
AS $$
SELECT public.ST_setbandnodatavalue($1, 1, $2, FALSE)
$$;
