create function st_neighborhood(rast raster, columnx integer, rowy integer, distancex integer, distancey integer, exclude_nodata_value boolean DEFAULT true) returns double precision[]
LANGUAGE SQL
AS $$
SELECT public._ST_neighborhood($1, 1, $2, $3, $4, $5, $6)
$$;
