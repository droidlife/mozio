create function st_clip(rast raster, geom geometry, nodataval double precision, crop boolean DEFAULT true) returns raster
LANGUAGE SQL
AS $$
SELECT ST_Clip($1, NULL, $2, ARRAY[$3]::double precision[], $4)
$$;
