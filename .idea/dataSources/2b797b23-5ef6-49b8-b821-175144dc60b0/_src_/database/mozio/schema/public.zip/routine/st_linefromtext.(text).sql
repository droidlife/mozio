create function st_linefromtext(text) returns geometry
LANGUAGE SQL
AS $$
SELECT CASE WHEN geometrytype(public.ST_GeomFromText($1)) = 'LINESTRING'
	THEN public.ST_GeomFromText($1)
	ELSE NULL END

$$;
