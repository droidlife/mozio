create function droprasterconstraints(rasttable name, rastcolumn name, VARIADIC constraints text[]) returns boolean
LANGUAGE SQL
AS $$
SELECT  public.DropRasterConstraints('', $1, $2, VARIADIC $3)
$$;
