create function raster_overright(raster, raster) returns boolean
LANGUAGE SQL
AS $$
select $1::public.geometry &> $2::public.geometry
$$;
