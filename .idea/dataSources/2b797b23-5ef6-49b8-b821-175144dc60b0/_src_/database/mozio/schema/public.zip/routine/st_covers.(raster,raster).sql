create function st_covers(rast1 raster, rast2 raster) returns boolean
LANGUAGE SQL
AS $$
SELECT public.st_covers($1, NULL::integer, $2, NULL::integer)
$$;
