create function st_clip(rast raster, nband integer, geom geometry, crop boolean) returns raster
LANGUAGE SQL
AS $$
SELECT ST_Clip($1, ARRAY[$2]::integer[], $3, null::double precision[], $4)
$$;
