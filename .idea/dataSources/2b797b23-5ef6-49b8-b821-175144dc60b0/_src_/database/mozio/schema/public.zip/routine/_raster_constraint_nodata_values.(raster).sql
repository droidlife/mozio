create function "_raster_constraint_nodata_values"(rast raster) returns numeric[]
LANGUAGE SQL
AS $$
SELECT array_agg(round(nodatavalue::numeric, 10))::numeric[] FROM public.ST_BandMetaData($1, ARRAY[]::int[]);
$$;
