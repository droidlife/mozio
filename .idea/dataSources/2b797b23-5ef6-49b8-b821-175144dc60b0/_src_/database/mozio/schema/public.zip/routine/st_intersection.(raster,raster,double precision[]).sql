create function st_intersection(rast1 raster, rast2 raster, nodataval double precision[]) returns raster
LANGUAGE SQL
AS $$
SELECT st_intersection($1, 1, $2, 1, 'BOTH', $3)
$$;
