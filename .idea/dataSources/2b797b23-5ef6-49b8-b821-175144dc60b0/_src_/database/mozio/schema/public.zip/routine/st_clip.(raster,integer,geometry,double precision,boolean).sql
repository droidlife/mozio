create function st_clip(rast raster, nband integer, geom geometry, nodataval double precision, crop boolean DEFAULT true) returns raster
LANGUAGE SQL
AS $$
SELECT ST_Clip($1, ARRAY[$2]::integer[], $3, ARRAY[$4]::double precision[], $5)
$$;
