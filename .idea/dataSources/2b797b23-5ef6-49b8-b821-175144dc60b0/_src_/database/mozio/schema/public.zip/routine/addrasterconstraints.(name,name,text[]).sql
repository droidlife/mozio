create function addrasterconstraints(rasttable name, rastcolumn name, VARIADIC constraints text[]) returns boolean
LANGUAGE SQL
AS $$
SELECT public.AddRasterConstraints('', $1, $2, VARIADIC $3)
$$;
