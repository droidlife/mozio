create function "_drop_raster_constraint_regular_blocking"(rastschema name, rasttable name, rastcolumn name) returns boolean
LANGUAGE SQL
AS $$
SELECT public._drop_raster_constraint($1, $2, 'enforce_regular_blocking_' || $3)
$$;
