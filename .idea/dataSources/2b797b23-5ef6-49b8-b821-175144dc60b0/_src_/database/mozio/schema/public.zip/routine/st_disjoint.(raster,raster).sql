create function st_disjoint(rast1 raster, rast2 raster) returns boolean
LANGUAGE SQL
AS $$
SELECT st_disjoint($1, NULL::integer, $2, NULL::integer)
$$;
