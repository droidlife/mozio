create function st_addband(rast raster, outdbfile text, outdbindex integer[], index integer DEFAULT NULL::integer, nodataval double precision DEFAULT NULL::double precision) returns raster
LANGUAGE SQL
AS $$
SELECT public.ST_AddBand($1, $4, $2, $3, $5)
$$;
