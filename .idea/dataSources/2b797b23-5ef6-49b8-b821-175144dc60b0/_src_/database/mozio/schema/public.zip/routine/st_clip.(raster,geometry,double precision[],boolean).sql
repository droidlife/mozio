create function st_clip(rast raster, geom geometry, nodataval double precision[] DEFAULT NULL::double precision[], crop boolean DEFAULT true) returns raster
LANGUAGE SQL
AS $$
SELECT ST_Clip($1, NULL, $2, $3, $4)
$$;
