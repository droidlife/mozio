create function dropoverviewconstraints(ovtable name, ovcolumn name) returns boolean
LANGUAGE SQL
AS $$
SELECT  public.DropOverviewConstraints('', $1, $2)
$$;
