create function addoverviewconstraints(ovtable name, ovcolumn name, reftable name, refcolumn name, ovfactor integer) returns boolean
LANGUAGE SQL
AS $$
SELECT  public.AddOverviewConstraints('', $1, $2, '', $3, $4, $5)
$$;
