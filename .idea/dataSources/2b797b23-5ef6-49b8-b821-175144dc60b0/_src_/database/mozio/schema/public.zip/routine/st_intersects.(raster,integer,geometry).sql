create function st_intersects(rast raster, nband integer, geom geometry) returns boolean
LANGUAGE SQL
AS $$
SELECT $1::geometry OPERATOR(public.&&) $3 AND public._st_intersects($3, $1, $2)
$$;
