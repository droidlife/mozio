create function st_clip(rast raster, geom geometry, crop boolean) returns raster
LANGUAGE SQL
AS $$
SELECT ST_Clip($1, NULL, $2, null::double precision[], $3)
$$;
