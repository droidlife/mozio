create function "_raster_constraint_info_regular_blocking"(rastschema name, rasttable name, rastcolumn name) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
		covtile boolean;
		spunique boolean;
	BEGIN
		-- check existance of constraints
		-- coverage tile constraint
		covtile := COALESCE( public._raster_constraint_info_coverage_tile($1, $2, $3), FALSE);

		-- spatially unique constraint
		spunique := COALESCE( public._raster_constraint_info_spatially_unique($1, $2, $3), FALSE);

		RETURN (covtile AND spunique);
	END;

$$;
