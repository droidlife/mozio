create function st_intersection(rast raster, geomin geometry) returns SETOF geomval
LANGUAGE SQL
AS $$
SELECT st_intersection($2, $1, 1)
$$;
