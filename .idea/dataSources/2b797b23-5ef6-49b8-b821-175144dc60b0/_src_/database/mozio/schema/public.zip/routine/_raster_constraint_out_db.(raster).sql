create function "_raster_constraint_out_db"(rast raster) returns boolean[]
LANGUAGE SQL
AS $$
SELECT array_agg(isoutdb)::boolean[] FROM public.ST_BandMetaData($1, ARRAY[]::int[]);
$$;
