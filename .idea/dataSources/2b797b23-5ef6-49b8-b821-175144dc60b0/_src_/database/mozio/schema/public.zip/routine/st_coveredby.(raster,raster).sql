create function st_coveredby(rast1 raster, rast2 raster) returns boolean
LANGUAGE SQL
AS $$
SELECT public.st_coveredby($1, NULL::integer, $2, NULL::integer)
$$;
