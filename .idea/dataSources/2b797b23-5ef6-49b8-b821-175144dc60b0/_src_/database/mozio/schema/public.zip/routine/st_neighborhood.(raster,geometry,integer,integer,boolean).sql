create function st_neighborhood(rast raster, pt geometry, distancex integer, distancey integer, exclude_nodata_value boolean DEFAULT true) returns double precision[]
LANGUAGE SQL
AS $$
SELECT st_neighborhood($1, 1, $2, $3, $4, $5)
$$;
