create function lockrow(text, text, text) returns integer
LANGUAGE SQL
AS $$
SELECT LockRow(current_schema(), $1, $2, $3, now()::timestamp+'1:00');
$$;
