create function "_raster_constraint_pixel_types"(rast raster) returns text[]
LANGUAGE SQL
AS $$
SELECT array_agg(pixeltype)::text[] FROM  public.ST_BandMetaData($1, ARRAY[]::int[]);
$$;
