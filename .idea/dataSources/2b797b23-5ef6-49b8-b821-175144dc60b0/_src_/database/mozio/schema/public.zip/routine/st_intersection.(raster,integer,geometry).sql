create function st_intersection(rast raster, band integer, geomin geometry) returns SETOF geomval
LANGUAGE SQL
AS $$
SELECT st_intersection($3, $1, $2)
$$;
