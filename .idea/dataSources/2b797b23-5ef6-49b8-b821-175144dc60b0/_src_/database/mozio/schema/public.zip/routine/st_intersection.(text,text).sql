create function st_intersection(text, text) returns geometry
LANGUAGE SQL
AS $$
SELECT public.ST_Intersection($1::public.geometry, $2::public.geometry);
$$;
