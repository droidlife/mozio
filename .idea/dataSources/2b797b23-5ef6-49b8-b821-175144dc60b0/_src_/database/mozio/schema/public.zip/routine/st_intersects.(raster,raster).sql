create function st_intersects(rast1 raster, rast2 raster) returns boolean
LANGUAGE SQL
AS $$
SELECT public.st_intersects($1, NULL::integer, $2, NULL::integer)
$$;
