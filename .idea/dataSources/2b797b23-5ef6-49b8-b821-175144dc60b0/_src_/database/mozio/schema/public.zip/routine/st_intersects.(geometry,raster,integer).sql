create function st_intersects(geom geometry, rast raster, nband integer DEFAULT NULL::integer) returns boolean
LANGUAGE SQL
AS $$
SELECT $1 OPERATOR(public.&&) $2::geometry AND public._st_intersects($1, $2, $3);
$$;
